package kosta.mvc.model.service;

import java.util.List;

public interface SuggestService {
	
	List<String> suggest(String keyWord);

}
