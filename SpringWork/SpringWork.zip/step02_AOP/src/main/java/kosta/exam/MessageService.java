package kosta.exam;

public interface MessageService {
	
	void korHello();
	void engHello();
	String hello();
	int hello(String name);
	

}
