package kosta.exam;

public interface MemberService {

	int insert();

	String select(int i);

	void update(String id);

}
