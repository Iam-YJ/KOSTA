package kosta.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Step28BootJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Step28BootJpaApplication.class, args);
	}

}
