package kosta.dto;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SalgradeDTO {

	private int grade;
	private int losal;
	private int hisal;
}
