package kosta.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DeptDTO {
	private int deptNo;
	private String dname;
	private String loc;

}