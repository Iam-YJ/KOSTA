package kosta.repository;

public class MainApp {

	public static void main(String[] args) {
		
		/*
		 * System.out.println("문제 1-1 ==================="); joinDAO.deptTest();
		 */
		
		System.out.println("문제 2-1 ===================");
		joinDAO.gradeTest();
		
		
		
	
		
		
	}

}
