package service;

import java.sql.SQLException;

import dao.MemberDAO;
import dao.MemberDAOImpl;
import dto.Member;
import dto.Word;
import exception.DuplicatedException;
import exception.NotFoundException;
import session.Session;
import session.SessionSet;

public class MemberService {
	static MemberDAO mdao = new MemberDAOImpl();

	public Member login(String userId, String password) throws SQLException, NotFoundException {
		Member member = mdao.login(userId, password);
		if (member == null) {
			throw new NotFoundException("��ġ�ϴ� ȸ�� ������ �����ϴ�.");
		}

		SessionSet sessionSet = SessionSet.getInstance();
		Session session = new Session(userId);
		sessionSet.add(session);

		return member;

	}

	public static Member register(String userId, String password, String nickName)
			throws SQLException, DuplicatedException {
		Member member = mdao.register(userId, password, nickName);

		if (member != null) {
			throw new DuplicatedException("�̹� �����ϴ� ȸ���Դϴ�.");
		}
		SessionSet sessionSet = SessionSet.getInstance();
		Session session = new Session(userId);
		sessionSet.add(session);
		return member;
	}
	
	/**
	 * ȸ�� ����
	 * */
	public int update(Member member) throws SQLException{
		int result = mdao.update(member);
		if(result ==0) {
			throw new SQLException("ȸ���� �������� ���߽��ϴ�");
		}
		return result;
	}
		
	/**
	 * ȸ�� ����
	 */
	public void delete(Member member) throws SQLException {
		int result = mdao.delete(member);
		if (result == 0)
			throw new SQLException("�������� �ʾҽ��ϴ�..");
	}
	
	
}
