package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import dto.Admin;
import dto.Member;
import dto.UserWord;
import util.DbUtil;

public class MemberDAOImpl implements MemberDAO {

	@Override
	public Member login(String userId, String password) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Member member = null;

		String sql = "select * from member where user_id=? and password =?";
		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(sql);
			ps.setString(1, userId);
			ps.setString(2, password);
			rs = ps.executeQuery();

			if (rs.next()) {
				member = new Member(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5));

				// �α��� ��...
				adminCheck(member);
				// �������������θ� üũ�Ѵ�. ( select * from admin where user_no = ? )
			}

		} finally {
			DbUtil.close(con, ps, rs);
		}

		return member;
	}

	public Admin adminCheck(Member member) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Admin admin = null;

		String sql = "select * from admin where user_no = ?";

		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(sql);
			ps.setInt(1, member.getUserNo());
			rs = ps.executeQuery();

			if (rs.next()) {
				admin.addAdmin(member);
			}

		} finally {
			DbUtil.dbClose(con, ps);
		}

		return admin;
	}

	@Override
	public Member register(String userId, String password, String nickName) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		int i = 0;
		Member member = null;

		String sql = "insert into member(user_no,user_id, password, nickname,points) values(USER_NO_SEQ.nextval,?,?,?,null)";

		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(sql);

			ps.setString(1, userId);
			ps.setString(2, password);
			ps.setString(3, nickName);
			i = ps.executeUpdate();

		} finally {
			DbUtil.dbClose(con, ps);
		}

		return member;
	}

	@Override
	public int update(Member member) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		String sql = "update member set password = ?, nickName =? where user_No=?";
		int result = 0;

		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(sql);

			ps.setString(1, member.getPassword());
			ps.setString(2, member.getNickName());
			ps.setInt(3, member.getUserNo());

			result = ps.executeUpdate();
		} finally {
			DbUtil.dbClose(con, ps);

		}

		return result;
	}

	@Override
	public int delete(Member member) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;
		int result = 0;
		String sql = "delete from member where user_no=?";

		try {
			con = DbUtil.getConnection();
			ps = con.prepareStatement(sql);

			ps.setInt(1, member.getUserNo());

			result = ps.executeUpdate();

		} finally {
			DbUtil.dbClose(con, ps);
		}
		return result;
	}

}
