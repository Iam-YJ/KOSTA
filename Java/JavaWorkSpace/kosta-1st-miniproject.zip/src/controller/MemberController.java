package controller;

import java.sql.SQLException;
import java.util.List;

import dto.Member;
import dto.Word;
import service.MemberService;
import view.EndView;
import view.FailView;
import view.MenuView;

public class MemberController {
	static MemberService memberService = new MemberService();

	/**
	 * �α���
	 */
	public static void login(String userId, String password) {
		try {
			Member member = memberService.login(userId, password);
			MenuView.printUserMenu(userId, member.getUserNo());

		} catch (Exception e) {
			FailView.errorMessage(e.getMessage());

		}
	}

	/**
	 * ȸ������
	 */
	public static void register(String userId, String password, String nickName) {
		try {
			Member member = MemberService.register(userId, password, nickName);
			MenuView.printUserMenu(userId, member.getUserNo());
		} catch (Exception e) {
			FailView.errorMessage(e.getMessage());
		}
	}

	/**
	 * ȸ�� ����
	 * */
	public static void memberUpdate(Member member) {
		try {
			memberService.update(member);
		}catch(SQLException e) {
			FailView.errorMessage(e.getMessage());
		}
	}
	
	/**
	 * ȸ�� ����
	 * */

	public static void memberDelete(Member member) {
		try {
			memberService.delete(member);
		}catch(SQLException e) {
			FailView.errorMessage(e.getMessage());
		}
	}
	
	/**
	 * �ܾ���� (��ü DB ����)
	 */
//	public static void wordTest() {
//
//		try {
//			List<Word> list = wordService.wordSelect();
//			EndView.wordTest(list); //���� �ٲ�ߵɵ�?
//			
//		} catch (Exception e) {
//			FailView.errorMessage(e.getMessage());
//		}
//	}
}
