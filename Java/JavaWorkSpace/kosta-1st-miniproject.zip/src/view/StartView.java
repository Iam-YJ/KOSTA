package view;

public class StartView {
	public static void main(String[] args) {
		 MenuView.menu();
	}
	
	

}
