package ex0806_Project.p277;

public class PrinterExam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//16
		/*
		Printer printer = new Printer();
		printer.println(10);
		printer.println(true);
		printer.println(5.7);
		printer.println("ȫ�浿");
		*/
		
		//17
		Printer.println(10);
		Printer.println(true);
		Printer.println(5.7);
		Printer.println("ȫ�浿");

	}

}
