package ex0806_Project.p277;

public class ShopService {
	
	private static ShopService s = new ShopService();
	
	public static ShopService getInstance() {
		return s;
	}
	
	

}
