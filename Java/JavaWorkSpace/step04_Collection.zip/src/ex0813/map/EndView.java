package ex0813.map;

public class EndView {
	
	public EndView() {
		
	}
	
	/* public static void printAll(Map<String, Person> map) {
		
	} */
	
	public static void printSearch(Person p) {
		
	}
	
	public static void printMessage(String name) {
		
	}
	

}
