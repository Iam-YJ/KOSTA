package kosta.mvc.exception;

public class AddException extends Exception {
	public  AddException() {
	}
	
	public AddException(String message) {
		super(message);
	}

}
