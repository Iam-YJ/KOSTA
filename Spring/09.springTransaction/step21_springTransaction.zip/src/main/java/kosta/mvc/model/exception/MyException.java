package kosta.mvc.model.exception;

public class MyException extends RuntimeException {
  public MyException() {}
  public MyException(String message) {
	  super(message);
  }
}
