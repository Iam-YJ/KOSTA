package assign1026;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class BoardServlet extends HttpServlet{
	//  application�������� list�� �����Ѵ�.
	String subject1, subject2, subject3;
	String name1, name2, name3;
	String date1, date2, date3;

	List<BoardDTO> subject_list = new ArrayList<BoardDTO>();
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		
		ServletContext application = config.getServletContext();
		
		subject1 = application.getInitParameter("subject1");
		subject2 = application.getInitParameter("subject2");
		subject3 = application.getInitParameter("subject3");
		
		name1 = application.getInitParameter("name1");
		name2 = application.getInitParameter("name2");
		name3 = application.getInitParameter("name3");
		
		date1 = application.getInitParameter("date1");
		date2 = application.getInitParameter("date2");
		date3 = application.getInitParameter("date3");
		
		subject_list.add(new BoardDTO(subject1, name1, date1));
		subject_list.add(new BoardDTO(subject2, name2, date2));
		subject_list.add(new BoardDTO(subject3, name3, date3));
		
		application.setAttribute("boardList", subject_list);
	}
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String sessionId = (String)session.getAttribute("getId"); //������ID

		String registerTime = new Date().toLocaleString();//�۵�Ͻð�
		
		request.setCharacterEncoding("UTF-8");//post���
		String subject = request.getParameter("subject");//����
		
		BoardDTO dto = new BoardDTO(subject,sessionId,registerTime);
		
		subject_list.add(dto);
		
		PrintWriter b_out = response.getWriter();
		b_out.println("<script>");
		b_out.println("top.location.href='index.jsp'");
		b_out.println("</script>");
	}
}
